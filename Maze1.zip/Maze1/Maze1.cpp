#include "Maze1.h"
#include <iostream>
#include <cassert>

using namespace std;

Maze1::~Maze1()
{
  // FILL IN THE CODE FOR THIS METHOD

}

void Maze1::find_exit()
// Use the DFS method to fill the path stack with the exit path Positions
// If there is no path to the exit, then after execution of this function
// the stack path should be empty
// This function does no input and no output
{
  // FILL IN THE CODE FOR THIS METHOD
  Position nbr, current;
  direction d;


}




